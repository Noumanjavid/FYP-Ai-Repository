# IIUI AI Repository - Database & Vercel Integration Guide

This guide details how to migrate this Vite-React frontend prototype from `localStorage` to a fully functional database and file storage solution hosted entirely on **Vercel**. 

Vercel is the ideal choice for this Final Year Project (FYP) because it offers a free tier for hobbyists/students, handles frontend deployments automatically via GitHub, and provides serverless SQL databases and PDF file storage under one unified dashboard.

---

## 🚀 Option A: Vercel Serverless Architecture (Recommended)

Using Vercel's built-in services allows you to build a full-stack application without managing a separate dedicated Express server. 

```mermaid
graph TD
    ReactApp[React Frontend - Vite] -->|HTTPS Fetch API| VercelAPI[Vercel Serverless Functions /api/*]
    VercelAPI -->|Query SQL| VercelPostgres[(Vercel Postgres - SQL DB)]
    VercelAPI -->|Upload PDF| VercelBlob[(Vercel Blob - PDF Storage)]
```

### Step 1: Deploying Your Site to Vercel
1. Push your project code to a private or public repository on **GitHub** (excluding `node_modules`).
2. Log into your account on [Vercel.com](https://vercel.com).
3. Click **Add New** > **Project** and import your GitHub repository.
4. Set the framework preset as **Vite** and click **Deploy**. Vercel will build and host your website instantly.

### Step 2: Provisioning Storage (Postgres & Blob)
On your Vercel project dashboard:
1. Navigate to the **Storage** tab.
2. Click **Create Database** > select **Postgres** (SQL database) and link it to your project. Vercel will automatically configure SQL environment variables (like `POSTGRES_URL`, `POSTGRES_USER`).
3. Click **Create Database** > select **Blob** (file storage bucket) and link it to your project. This will generate your `BLOB_READ_WRITE_TOKEN` to store uploaded PDF thesis papers.

### Step 3: Install Vercel SDK Libraries
Install the official serverless drivers in your React project root directory:
```bash
npm install @vercel/postgres @vercel/blob
```

### Step 4: Create the Serverless API Router (`api/projects.js`)
Vercel allows you to write serverless backend routes inside a directory named `/api` in the project root. Create a file `/api/projects.js`:

```javascript
import { db } from '@vercel/postgres';
import { put } from '@vercel/blob';

export default async function handler(req, response) {
  const client = await db.connect();

  try {
    // 1. Ensure Table exists in Vercel Postgres
    await client.sql`
      CREATE TABLE IF NOT EXISTS projects (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        authors TEXT[] NOT NULL,
        advisors TEXT[] NOT NULL,
        department TEXT NOT NULL,
        level TEXT NOT NULL,
        type TEXT NOT NULL,
        year INTEGER NOT NULL,
        abstract TEXT NOT NULL,
        githubUrl TEXT,
        demoUrl TEXT,
        documentUrl TEXT,
        tags TEXT[] NOT NULL,
        status TEXT DEFAULT 'Approved'
      );
    `;

    // 2. GET request: Fetch all projects
    if (req.method === 'GET') {
      const { rows } = await client.sql`
        SELECT * FROM projects ORDER BY id DESC;
      `;
      return response.status(200).json(rows);
    }

    // 3. POST request: Upload project metadata
    if (req.method === 'POST') {
      const { title, authors, advisors, department, level, type, year, abstract, githubUrl, demoUrl, documentUrl, tags } = req.body;
      
      const { rows } = await client.sql`
        INSERT INTO projects (title, authors, advisors, department, level, type, year, abstract, githubUrl, demoUrl, documentUrl, tags)
        VALUES (${title}, ${authors}, ${advisors}, ${department}, ${level}, ${type}, ${year}, ${abstract}, ${githubUrl}, ${demoUrl}, ${documentUrl}, ${tags})
        RETURNING *;
      `;
      return response.status(201).json(rows[0]);
    }

    return response.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    return response.status(500).json({ error: error.message });
  }
}
```

### Step 5: Connecting PDF File Uploads (`api/upload.js`)
To upload actual student PDF thesis files to Vercel Blob, create `/api/upload.js`:

```javascript
import { put } from '@vercel/blob';

export default async function handler(req, response) {
  if (req.method !== 'POST') {
    return response.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const filename = req.headers['x-filename'] || 'thesis_draft.pdf';
    
    // Upload the incoming file stream directly to Vercel Blob Storage
    const blob = await put(filename, req, {
      access: 'public',
    });

    return response.status(200).json(blob);
  } catch (error) {
    return response.status(500).json({ error: error.message });
  }
}
```

### Step 6: Update React Frontend Fetch Queries (`src/App.jsx`)
Replace the local mock state calls with calls to your Vercel Serverless Endpoints:

```javascript
// A. Fetch all live projects on website load
useEffect(() => {
  fetch('/api/projects')
    .then(res => res.json())
    .then(data => setProjects(data))
    .catch(err => console.error("Error fetching projects:", err));
}, []);

// B. Upload file to Vercel Blob & Project details to Postgres inside handleAddProject
const handleAddProject = async (projectData, fileObject) => {
  try {
    let documentUrl = "IIUI_Research_Document.pdf";

    // 1. If the student selected a real local PDF file
    if (fileObject) {
      triggerNotification("Uploading PDF file to Vercel Blob...", "info");
      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'x-filename': fileObject.name,
        },
        body: fileObject, // Pass the binary stream
      });
      
      const blobResult = await uploadRes.json();
      documentUrl = blobResult.url; // This returns the live Vercel HTTPS CDN URL!
    }

    // 2. Post project metadata to Vercel Postgres SQL Database
    triggerNotification("Publishing project details...", "info");
    const projectRes = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...projectData,
        documentUrl // Save the CDN URL of the PDF
      })
    });

    const savedProject = await projectRes.json();
    setProjects([savedProject, ...projects]);
    triggerNotification("Your project is now published live!", "success");
  } catch (error) {
    triggerNotification("Database publishing failed: " + error.message, "error");
  }
};
```

---

## ⚡ Option B: Supabase Serverless SQL (Easiest Database-only Option)

If you prefer to host your files and data on a dedicated SQL service, Supabase integrates beautifully with Vercel:

1. Create a free account on [Supabase.com](https://supabase.com).
2. Create a new project and initialize a `projects` table inside their SQL Editor.
3. Install `@supabase/supabase-js` in your Vite project:
   ```bash
   npm install @supabase/supabase-js
   ```
4. Define a client hook in `src/supabaseClient.js`:
   ```javascript
   import { createClient } from '@supabase/supabase-js';
   export const supabase = createClient(
     import.meta.env.VITE_SUPABASE_URL,
     import.meta.env.VITE_SUPABASE_ANON_KEY
   );
   ```
5. In the **Vercel Dashboard**, go to your Project Settings > **Environment Variables** and add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to deploy it securely.
