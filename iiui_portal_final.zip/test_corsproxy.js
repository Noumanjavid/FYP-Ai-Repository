fetch('https://corsproxy.io/?https://text.pollinations.ai/', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    messages: [
      { role: 'system', content: 'You are a helpful assistant.' },
      { role: 'user', content: 'Say hello and stop.' }
    ]
  })
}).then(r => r.text()).then(console.log).catch(console.error);
