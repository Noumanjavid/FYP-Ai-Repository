import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;
const DB_FILE = path.join(__dirname, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

// Ensure database and uploads folders exist
function initDb() {
  if (!fs.existsSync(DB_FILE)) {
    // Seed database with mock data initially
    const mockDataFile = path.join(__dirname, 'src', 'data', 'mockData.js');
    let seedData = [];
    try {
      if (fs.existsSync(mockDataFile)) {
        // Read file contents to extract mock database items if needed
        console.log("Database initialized. Ready for entries.");
      }
    } catch (e) {
      console.warn("Could not find mockData.js for seeding, starting fresh.", e);
    }
    fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

app.use(cors());
app.use(express.json({ limit: '15mb' }));

// Health Check / Check backend status
app.get('/api/health', (req, res) => {
  initDb();
  res.json({ status: 'healthy', database: 'JSON_File_DB', port: PORT });
});

// Fetch all projects
app.get('/api/projects', (req, res) => {
  try {
    initDb();
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    res.json(JSON.parse(data));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Write / sync projects list (overwrites database)
app.post('/api/projects/sync', (req, res) => {
  try {
    initDb();
    const projects = req.body;
    fs.writeFileSync(DB_FILE, JSON.stringify(projects, null, 2));
    res.json({ success: true, count: projects.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a single new project
app.post('/api/projects', (req, res) => {
  try {
    initDb();
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    const projects = JSON.parse(data);
    const newProject = req.body;
    
    // Auto-generate ID if missing
    if (!newProject.id) {
      newProject.id = `proj-${Date.now()}`;
    }
    
    projects.unshift(newProject);
    fs.writeFileSync(DB_FILE, JSON.stringify(projects, null, 2));
    res.status(201).json(newProject);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Fetch all students (auth system integration)
app.get('/api/students', (req, res) => {
  try {
    const studentsFile = path.join(__dirname, 'students.json');
    if (!fs.existsSync(studentsFile)) {
      const defaultStudent = [{ email: "student1@iiu.edu.pk", password: "password123", name: "Ahmad Ali", department: "Computer Science" }];
      fs.writeFileSync(studentsFile, JSON.stringify(defaultStudent, null, 2));
    }
    const data = fs.readFileSync(studentsFile, 'utf-8');
    res.json(JSON.parse(data));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Sync students
app.post('/api/students/sync', (req, res) => {
  try {
    const studentsFile = path.join(__dirname, 'students.json');
    const students = req.body;
    fs.writeFileSync(studentsFile, JSON.stringify(students, null, 2));
    res.json({ success: true, count: students.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Handle raw PDF file uploads (binary stream write)
app.post('/api/upload', express.raw({ type: 'application/pdf', limit: '15mb' }), (req, res) => {
  try {
    initDb();
    const filename = req.headers['x-filename'] || `document_${Date.now()}.pdf`;
    // Clean filename to prevent path traversal
    const safeFilename = path.basename(filename).replace(/[^a-zA-Z0-9_.-]/g, '_');
    const filePath = path.join(UPLOADS_DIR, safeFilename);
    
    fs.writeFileSync(filePath, req.body);
    console.log(`Uploaded file saved to: ${filePath}`);
    
    // Return relative URL that our Vite public server can serve (or backend can serve)
    res.json({ url: `/uploads/${safeFilename}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Serve static uploads
app.use('/uploads', express.static(UPLOADS_DIR));

// Start server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`IIUI Research Database Server is running locally!`);
  console.log(`Port: ${PORT}`);
  console.log(`Database File: ${DB_FILE}`);
  console.log(`API endpoints available at http://localhost:${PORT}/api/projects`);
  console.log(`====================================================`);
});
