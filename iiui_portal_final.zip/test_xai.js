const key = "xai-cbVpixhpFce1iAghf0nmjUvqcY6HyiyvRCSGWS3jbdwKyumoFu9cIFWzsZHpnIWJcgt2FwemxYc3AE9D";
fetch('https://api.x.ai/v1/chat/completions', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${key}`
  },
  body: JSON.stringify({
    model: 'grok-2-latest',
    messages: [{role: 'user', content: 'test'}]
  })
}).then(r => r.json()).then(d => console.log(JSON.stringify(d, null, 2))).catch(console.error);
