const key = "xai-cbVpixhpFce1iAghf0nmjUvqcY6HyiyvRCSGWS3jbdwKyumoFu9cIFWzsZHpnIWJcgt2FwemxYc3AE9D";
fetch('https://api.x.ai/v1/models', {
  headers: {
    'Authorization': `Bearer ${key}`
  }
}).then(r => r.json()).then(d => console.log(JSON.stringify(d, null, 2))).catch(console.error);
