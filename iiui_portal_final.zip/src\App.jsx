import React, { useState, useEffect } from 'react';
import { initialProjects, iiuiDepartments } from './data/mockData';
import Showcase from './components/Showcase';
import StudentPortal from './components/StudentPortal';
import DatabaseManager from './components/DatabaseManager';

// Force-refresh localStorage with latest project data (ensures new departments show)
const DATA_VERSION = 'v5_auth_email';
if (localStorage.getItem('iiui_data_version') !== DATA_VERSION) {
  localStorage.setItem('iiui_projects', JSON.stringify(initialProjects));
  localStorage.setItem('iiui_data_version', DATA_VERSION);
}
if (!localStorage.getItem('iiui_students')) {
  localStorage.setItem('iiui_students', JSON.stringify([
    { email: "student1@iiu.edu.pk", password: "password123", name: "Ahmad Ali", department: "Computer Science" }
  ]));
}

function App() {
  const clickCount = React.useRef(0);
  const [currentView, setCurrentView] = useState('showcase'); // 'showcase' | 'upload' | 'database'
  const [dbMode, setDbMode] = useState('local'); // 'local' | 'backend'
  const [projects, setProjects] = useState([]);
  const [students, setStudents] = useState([]);
  const [activeStudent, setActiveStudent] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [notification, setNotification] = useState(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    return localStorage.getItem('sidebar_collapsed') === 'true';
  });

  const handleToggleSidebar = () => {
    const newCollapsed = !isSidebarCollapsed;
    setIsSidebarCollapsed(newCollapsed);
    localStorage.setItem('sidebar_collapsed', String(newCollapsed));
  };

  // Load state from local server or localStorage fallback on mount
  useEffect(() => {
    fetch('http://localhost:3001/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'healthy') {
          setDbMode('backend');
          fetch('http://localhost:3001/api/projects')
            .then(res => res.json())
            .then(projData => setProjects(projData))
            .catch(e => console.error("Error loading server projects", e));
          
          fetch('http://localhost:3001/api/students')
            .then(res => res.json())
            .then(studData => setStudents(studData))
            .catch(e => console.error("Error loading server students", e));
          console.log("Connected to local research repository Express server database!");
        }
      })
      .catch(() => {
        console.log("Local database server offline. Using local browser storage fallback.");
        const storedProjects = JSON.parse(localStorage.getItem('iiui_projects') || '[]');
        const storedStudents = JSON.parse(localStorage.getItem('iiui_students') || '[]');
        setProjects(storedProjects);
        setStudents(storedStudents);
      });

    // Persist logins in session if they exist
    const sessStudent = sessionStorage.getItem('active_student');
    if (sessStudent) setActiveStudent(JSON.parse(sessStudent));

    // Dark mode state
    const savedDarkMode = localStorage.getItem('dark_mode') === 'true';
    setDarkMode(savedDarkMode);
    if (savedDarkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, []);

  // Track mouse cursor movement for premium trailing cursor
  useEffect(() => {
    const cursorDot = document.querySelector('.cursor-dot');
    const cursorOutline = document.querySelector('.cursor-outline');
    
    if (!cursorDot || !cursorOutline) return;
    
    const moveCursor = (e) => {
      const posX = e.clientX;
      const posY = e.clientY;
      
      cursorDot.style.left = `${posX}px`;
      cursorDot.style.top = `${posY}px`;
      
      cursorOutline.animate({
        left: `${posX}px`,
        top: `${posY}px`
      }, { duration: 120, fill: 'forwards' });
    };
    
    window.addEventListener('mousemove', moveCursor);
    
    const handleHover = () => {
      cursorOutline.classList.add('cursor-hover');
      cursorDot.classList.add('cursor-hover');
    };
    const handleUnhover = () => {
      cursorOutline.classList.remove('cursor-hover');
      cursorDot.classList.remove('cursor-hover');
    };
    
    const attachHoverHandlers = () => {
      const interactives = document.querySelectorAll('a, button, [role="button"], input, select, textarea, .nav-item, .project-card, .stat-card, .student-project-card');
      interactives.forEach(el => {
        el.addEventListener('mouseenter', handleHover);
        el.addEventListener('mouseleave', handleUnhover);
      });
      return interactives;
    };

    let interactives = attachHoverHandlers();

    // Periodically re-attach handlers to dynamic/re-rendered content
    const interval = setInterval(() => {
      interactives.forEach(el => {
        el.removeEventListener('mouseenter', handleHover);
        el.removeEventListener('mouseleave', handleUnhover);
      });
      interactives = attachHoverHandlers();
    }, 1500);
    
    return () => {
      window.removeEventListener('mousemove', moveCursor);
      clearInterval(interval);
      interactives.forEach(el => {
        el.removeEventListener('mouseenter', handleHover);
        el.removeEventListener('mouseleave', handleUnhover);
      });
    };
  }, [currentView, projects]);

  // Sync projects helper
  const syncProjects = (updatedProjects) => {
    setProjects(updatedProjects);
    localStorage.setItem('iiui_projects', JSON.stringify(updatedProjects));
    
    if (dbMode === 'backend') {
      fetch('http://localhost:3001/api/projects/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedProjects)
      }).catch(err => console.error("Failed to sync projects to database server:", err));
    }
  };

  const syncStudents = (updatedStudents) => {
    setStudents(updatedStudents);
    localStorage.setItem('iiui_students', JSON.stringify(updatedStudents));
    
    if (dbMode === 'backend') {
      fetch('http://localhost:3001/api/students/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedStudents)
      }).catch(err => console.error("Failed to sync students to database server:", err));
    }
  };

  // Notification helper
  const triggerNotification = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Toggle Dark Mode
  const handleToggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('dark_mode', String(newDarkMode));
    if (newDarkMode) {
      document.body.classList.add('dark-mode');
      triggerNotification("Dark mode enabled", "info");
    } else {
      document.body.classList.remove('dark-mode');
      triggerNotification("Light mode enabled", "info");
    }
  };

  // Authentication operations
  const handleStudentRegister = (name, email, password, department) => {
    if (!email.endsWith('@iiu.edu.pk')) {
      triggerNotification("Registration requires a valid @iiu.edu.pk email address.", "error");
      return false;
    }
    if (students.find(s => s.email === email)) {
      triggerNotification("Email is already registered!", "error");
      return false;
    }
    const newStudent = { name, email, password, department };
    const updated = [...students, newStudent];
    syncStudents(updated);
    setActiveStudent(newStudent);
    sessionStorage.setItem('active_student', JSON.stringify(newStudent));
    triggerNotification(`Welcome, ${name}! Student account registered.`, "success");
    return true;
  };

  const handleStudentLogin = (email, password) => {
    const student = students.find(s => s.email === email && s.password === password);
    if (student) {
      setActiveStudent(student);
      sessionStorage.setItem('active_student', JSON.stringify(student));
      triggerNotification(`Welcome back, ${student.name}!`, "success");
      return true;
    }
    triggerNotification("Invalid credentials or email not found.", "error");
    return false;
  };

  const handleLogout = () => {
    setActiveStudent(null);
    sessionStorage.removeItem('active_student');
    triggerNotification("Logged out successfully.", "info");
  };

  // Submission operations
  const handleAddProject = async (projectData, fileObject) => {
    if (!activeStudent) {
      triggerNotification("You must be logged in to upload.", "error");
      return;
    }

    let documentUrl = projectData.documentUrl || "Thesis_Report.pdf";

    if (fileObject) {
      if (dbMode === 'backend') {
        triggerNotification("Uploading PDF file to server database...", "info");
        try {
          const arrayBuffer = await fileObject.arrayBuffer();
          const uploadRes = await fetch('http://localhost:3001/api/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/pdf',
              'x-filename': fileObject.name
            },
            body: arrayBuffer
          });
          const uploadData = await uploadRes.json();
          documentUrl = `http://localhost:3001${uploadData.url}`;
        } catch (err) {
          console.error("Local file upload failed, using fallback URL", err);
          documentUrl = URL.createObjectURL(fileObject);
        }
      } else {
        documentUrl = URL.createObjectURL(fileObject);
      }
    }

    const newProject = {
      id: `proj-${Date.now()}`,
      title: projectData.title,
      authors: projectData.authors,
      advisors: projectData.advisors,
      department: projectData.department,
      level: projectData.level,
      type: projectData.type,
      year: parseInt(projectData.year) || new Date().getFullYear(),
      abstract: projectData.abstract,
      documentUrl,
      tags: projectData.tags,
      status: "Approved",
      grade: "",
      reviews: [],
      uploaderEmail: activeStudent.email // Track who uploaded this
    };

    const updated = [newProject, ...projects];
    syncProjects(updated);
    triggerNotification("Your project has been published successfully!", "success");
  };

  const handleDeleteProject = (projectId) => {
    const updated = projects.filter(p => p.id !== projectId);
    syncProjects(updated);
    triggerNotification("Project deleted successfully.", "info");
  };

  const handleResetDatabase = () => {
    syncProjects([]);
    triggerNotification("Database wiped! Preloaded dummy projects deleted.", "info");
  };

  const handleImportData = (importedProjects) => {
    const formatted = importedProjects.map((p, idx) => ({
      id: p.id || `imported-${Date.now()}-${idx}`,
      title: p.title,
      authors: p.authors || ["Anonymous"],
      advisors: p.advisors || ["Faculty Advisor"],
      department: p.department || "Computer Science",
      level: p.level || "BS",
      type: p.type || "Thesis",
      year: parseInt(p.year) || new Date().getFullYear(),
      abstract: p.abstract || "No abstract provided.",
      documentUrl: p.documentUrl || "IIUI_Research_Document.pdf",
      tags: p.tags || ["AI"],
      status: p.status || "Approved",
      grade: p.grade || "",
      reviews: p.reviews || []
    }));
    const updated = [...formatted, ...projects];
    syncProjects(updated);
  };

  const handleLogoClick = () => {
    // Rapid click easter egg logic (3 clicks)
    clickCount.current += 1;
    
    if (clickCount.current === 3) {
      clickCount.current = 0; // reset
      const passcode = prompt("Enter Admin Passcode to open Database Controls:");
      if (passcode === "iiui_admin") {
        setCurrentView('database');
        triggerNotification("Access granted. Database controls unlocked.", "success");
      } else if (passcode !== null) {
        triggerNotification("Incorrect passcode.", "error");
      }
      return;
    }
    
    // Reset counter after 1 second
    setTimeout(() => {
      clickCount.current = 0;
    }, 1000);

    // Normal click behavior
    setCurrentView('showcase');
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="app-container">
      {/* Custom trailing cursor dot & outline */}
      <div className="cursor-dot"></div>
      <div className="cursor-outline"></div>

      {/* Live Flowy Animations Backdrop */}
      <div className="bg-grid"></div>
      <div className="bg-animation"></div>
      <div className="floating-node node-1"></div>
      <div className="floating-node node-2"></div>
      <div className="floating-node node-3"></div>

      {/* Mobile Top Header */}
      <header className="mobile-header">
        <div 
          className="mobile-logo" 
          onClick={handleLogoClick}
          title="Triple click for Admin Settings"
        >
          <img 
            src="/iiui-logo.png" 
            alt="IIUI Logo" 
            className="logo-icon-mobile" 
            style={{ width: '36px', height: '36px', filter: 'drop-shadow(0 0 8px rgba(0, 243, 255, 0.3))' }}
          />
          <div className="mobile-logo-text">
            <h1>IIUI AI Portal</h1>
            <span>Islamic University</span>
          </div>
        </div>
        <div className="mobile-header-actions">
          <button 
            className="theme-toggle-btn-mobile" 
            onClick={handleToggleDarkMode}
            title="Toggle theme mode"
            aria-label="Toggle theme mode"
          >
            {darkMode ? '☀️' : '🌙'}
          </button>
          <button 
            className="mobile-menu-toggle" 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            title="Toggle Menu"
            aria-label="Toggle Menu"
          >
            ☰
          </button>
        </div>
      </header>

      {/* Mobile Sidebar Drawer Backdrop */}
      {isMobileMenuOpen && (
        <div className="sidebar-backdrop" onClick={() => setIsMobileMenuOpen(false)}></div>
      )}

      {/* Sidebar Navigation */}
      <aside className={`app-sidebar ${isSidebarCollapsed ? 'collapsed' : ''} ${isMobileMenuOpen ? 'mobile-open' : ''}`}>
        <button 
          className="sidebar-collapse-toggle" 
          onClick={handleToggleSidebar}
          title={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-label={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isSidebarCollapsed ? '→' : '←'}
        </button>
        <div 
          className="logo-section" 
          onClick={handleLogoClick} 
          style={{ cursor: 'pointer' }}
          title="Triple click for Admin Settings"
        >
          <img 
            src="/iiui-logo.png" 
            alt="IIUI Logo" 
            className="logo-icon" 
            style={{ width: '48px', height: '48px', filter: 'drop-shadow(0 0 10px rgba(0, 243, 255, 0.3))' }}
          />
          <div className="logo-text">
            <h1>IIUI AI Portal</h1>
            <span>Islamic University</span>
          </div>
        </div>

        <nav className="nav-links">
          <div 
            className={`nav-item ${currentView === 'showcase' ? 'active' : ''}`}
            onClick={() => { setCurrentView('showcase'); setIsMobileMenuOpen(false); }}
          >
            <span className="nav-icon">
              <svg className="nav-icon-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
            </span>
            <span className="nav-label">Explore Work</span>
          </div>
          
          <div 
            className={`nav-item ${currentView === 'upload' ? 'active' : ''}`}
            onClick={() => { setCurrentView('upload'); setIsMobileMenuOpen(false); }}
          >
            <span className="nav-icon">
              <svg className="nav-icon-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
                <path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"></path>
              </svg>
            </span>
            <span className="nav-label">Scholar Dashboard {activeStudent && "✓"}</span>
          </div>
        </nav>

        <div className="sidebar-footer">
          {activeStudent ? (
            <div className="user-profile-summary">
              <div className="profile-avatar" style={{ background: 'var(--emerald-muted)', color: 'var(--emerald)' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </div>
              <div className="profile-info">
                <span className="profile-name">{activeStudent.name}</span>
                <span className="profile-email">{activeStudent.email}</span>
              </div>
            </div>
          ) : (
            <div className="user-profile-summary anonymous" onClick={() => { setCurrentView('upload'); setIsMobileMenuOpen(false); }}>
              <div className="profile-avatar">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
              </div>
              <div className="profile-info">
                <span className="profile-name">Guest Scholar</span>
                <span className="profile-email">Sign in to dashboard</span>
              </div>
            </div>
          )}

          <div className="theme-toggle-row">
            <span className="theme-label">Theme Mode</span>
            <button 
              className="theme-toggle-btn" 
              onClick={handleToggleDarkMode} 
              title="Toggle theme mode"
              aria-label="Toggle theme mode"
            >
              {darkMode ? '☀️' : '🌙'}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Workspace Wrapper */}
      <div className={`main-layout-wrapper ${isSidebarCollapsed ? 'collapsed' : ''}`}>
        <main className="main-content">
          {currentView === 'showcase' && (
            <Showcase 
              projects={projects.filter(p => p.status === 'Approved')} 
              onNavigateStudent={() => setCurrentView('upload')}
            />
          )}
          
          {currentView === 'upload' && (
            <StudentPortal 
              activeStudent={activeStudent}
              onRegister={handleStudentRegister}
              onLogin={handleStudentLogin}
              onLogout={handleLogout}
              onSubmitProject={handleAddProject}
              onDeleteProject={handleDeleteProject}
              projects={projects}
            />
          )}

          {currentView === 'database' && (
            <DatabaseManager 
              dbMode={dbMode}
              projects={projects}
              students={students}
              onResetDatabase={handleResetDatabase}
              onImportData={handleImportData}
              triggerNotification={triggerNotification}
            />
          )}
        </main>

        {/* Feedback Banner Notification */}
        {notification && (
          <div className={`notification-banner notification-${notification.type}`}>
            {notification.type === 'success' && '✓'}
            {notification.type === 'error' && '✗'}
            {notification.type === 'info' && '🛈'}
            <span>{notification.message}</span>
          </div>
        )}

        {/* Footer */}
        <footer className="app-footer">
          <div className="footer-content">
            <p>© {new Date().getFullYear()} International Islamic University, Islamabad — All Faculties & Departments.</p>
            <p>AI Research Repository & Student Academic Portal.</p>
            <div className="footer-links">
              <a href="https://iiu.edu.pk" target="_blank" rel="noopener noreferrer">IIUI Official Website</a>
              <span>•</span>
              <a href="#privacy">Academic Integrity Policy</a>
              <span>•</span>
              <a href="#help">System Support</a>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
