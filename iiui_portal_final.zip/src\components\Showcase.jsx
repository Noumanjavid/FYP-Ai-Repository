import React, { useState, useMemo } from 'react';

export default function Showcase({ projects, onNavigateStudent }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');
  const [selectedTag, setSelectedTag] = useState('');
  const [activeProject, setActiveProject] = useState(null);
  const [viewingDoc, setViewingDoc] = useState(null);

  // Derived filter options
  const departments = useMemo(() => ['All', ...new Set(projects.map(p => p.department))], [projects]);
  const levels = useMemo(() => ['All', ...new Set(projects.map(p => p.level))], [projects]);
  const types = useMemo(() => ['All', ...new Set(projects.map(p => p.type))], [projects]);
  const years = useMemo(() => ['All', ...new Set(projects.map(p => String(p.year)))].sort((a, b) => b - a), [projects]);

  // Popular tags
  const popularTags = useMemo(() => {
    const counts = {};
    projects.forEach(p => p.tags.forEach(tag => { counts[tag] = (counts[tag] || 0) + 1; }));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10).map(e => e[0]);
  }, [projects]);

  // Filtered projects
  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const q = searchTerm.toLowerCase();
      const matchSearch = !q ||
        p.title.toLowerCase().includes(q) ||
        p.abstract.toLowerCase().includes(q) ||
        p.authors.some(a => a.toLowerCase().includes(q)) ||
        p.tags.some(t => t.toLowerCase().includes(q)) ||
        p.department.toLowerCase().includes(q);
      return matchSearch
        && (selectedDept === 'All' || p.department === selectedDept)
        && (selectedLevel === 'All' || p.level === selectedLevel)
        && (selectedType === 'All' || p.type === selectedType)
        && (selectedYear === 'All' || String(p.year) === selectedYear)
        && (!selectedTag || p.tags.includes(selectedTag));
    });
  }, [projects, searchTerm, selectedDept, selectedLevel, selectedType, selectedYear, selectedTag]);

  // Stats
  const stats = useMemo(() => ({
    total: projects.length,
    msPhd: projects.filter(p => p.level === 'MS' || p.level === 'PhD').length,
    bs: projects.filter(p => p.level === 'BS').length,
    depts: new Set(projects.map(p => p.department)).size,
  }), [projects]);

  // Level chart data
  const levelData = useMemo(() => {
    const c = { BS: 0, MS: 0, PhD: 0 };
    projects.forEach(p => { if (c[p.level] !== undefined) c[p.level]++; });
    const t = c.BS + c.MS + c.PhD;
    return {
      BS: { count: c.BS, pct: t > 0 ? (c.BS / t) * 100 : 0 },
      MS: { count: c.MS, pct: t > 0 ? (c.MS / t) * 100 : 0 },
      PhD: { count: c.PhD, pct: t > 0 ? (c.PhD / t) * 100 : 0 },
      total: t,
    };
  }, [projects]);

  // Department chart data — sorted desc
  const deptData = useMemo(() => {
    const c = {};
    projects.forEach(p => { c[p.department] = (c[p.department] || 0) + 1; });
    return Object.entries(c).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  }, [projects]);

  // Donut slices
  const donutSlices = useMemo(() => {
    const r = 50, circ = 2 * Math.PI * r;
    let offset = 0;
    const items = [
      { key: 'BS', data: levelData.BS, color: '#D4A853' },
      { key: 'MS', data: levelData.MS, color: '#4ADE80' },
      { key: 'PhD', data: levelData.PhD, color: '#A78BFA' },
    ];
    return items.map(item => {
      const len = (item.data.pct / 100) * circ;
      const slice = {
        key: item.key, color: item.color,
        dashArray: `${len} ${circ - len}`,
        dashOffset: -offset,
        pct: item.data.pct.toFixed(0),
        count: item.data.count,
      };
      offset += len;
      return slice;
    });
  }, [levelData]);

  const barColors = ['#D4A853', '#4ADE80', '#A78BFA', '#FB7185', '#22D3EE', '#F97316', '#60A5FA', '#E879F9', '#34D399', '#FBBF24', '#818CF8', '#F43F5E'];

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedDept('All');
    setSelectedLevel('All');
    setSelectedType('All');
    setSelectedYear('All');
    setSelectedTag('');
  };

  const hasFilters = searchTerm || selectedDept !== 'All' || selectedLevel !== 'All' || selectedType !== 'All' || selectedYear !== 'All' || selectedTag;

  return (
    <div className="showcase-container">

      {/* ── Hero ──────────────────────────────── */}
      <section className="hero-section">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <span className="hero-tagline">International Islamic University, Islamabad</span>
          <h2 className="hero-title">AI Research Portal</h2>
          <p className="hero-desc">
            Explore AI-powered research across all IIUI faculties — computer science, economics, Shariah studies, engineering, and more. A unified portal for BS, MS & PhD academic work.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-primary" onClick={onNavigateStudent}>
              Publish Your Research →
            </button>
            <a href="#explore" className="btn btn-secondary">
              Browse Projects
            </a>
          </div>
        </div>
      </section>

      {/* ── Stats ─────────────────────────────── */}
      <section className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper">📚</div>
          <div className="stat-info">
            <h3>{stats.total}</h3>
            <p>Total Projects</p>
          </div>
          <svg className="sparkline" width="60" height="30" viewBox="0 0 60 30">
            <path d="M 0 25 Q 15 15 30 20 T 60 5" fill="none" stroke="var(--gold-light)" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper">🔬</div>
          <div className="stat-info">
            <h3>{stats.msPhd}</h3>
            <p>MS & PhD Theses</p>
          </div>
          <svg className="sparkline" width="60" height="30" viewBox="0 0 60 30">
            <path d="M 0 20 Q 15 25 30 10 T 60 15" fill="none" stroke="var(--emerald)" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper">🎓</div>
          <div className="stat-info">
            <h3>{stats.bs}</h3>
            <p>BS Capstone</p>
          </div>
          <svg className="sparkline" width="60" height="30" viewBox="0 0 60 30">
            <path d="M 0 28 Q 15 25 30 18 T 60 8" fill="none" stroke="var(--violet)" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper">🏛️</div>
          <div className="stat-info">
            <h3>{stats.depts}</h3>
            <p>Departments</p>
          </div>
          <svg className="sparkline" width="60" height="30" viewBox="0 0 60 30">
            <path d="M 0 15 Q 15 15 30 18 T 60 12" fill="none" stroke="var(--cyan)" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
      </section>

      {/* ── Two-Column Layout ─────────────────── */}
      <div id="explore" className="showcase-layout">
        
        {/* Left: Search + Grid */}
        <div className="showcase-main">
          
          {/* Search & Filters */}
          <div className="search-filter-card">
            <div className="search-box-wrapper">
              <input
                type="text"
                className="search-input"
                placeholder="Search by title, author, department, or keyword..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg className="search-icon-svg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>

            <div className="filters-toolbar">
              <div className="filter-segment-group">
                <span className="filter-label">Level</span>
                <div className="segmented-tabs">
                  {levels.map(l => (
                    <button
                      key={l}
                      className={`segment-btn ${selectedLevel === l ? 'active' : ''}`}
                      onClick={() => setSelectedLevel(l)}
                    >
                      {l === 'All' ? 'All' : l}
                    </button>
                  ))}
                </div>
              </div>

              <div className="filter-segment-group">
                <span className="filter-label">Type</span>
                <div className="segmented-tabs">
                  {types.map(t => (
                    <button
                      key={t}
                      className={`segment-btn ${selectedType === t ? 'active' : ''}`}
                      onClick={() => setSelectedType(t)}
                    >
                      {t === 'All' ? 'All' : t === 'Tangible Project' ? 'Applied AI' : t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="filter-dropdown-group">
                <div className="filter-group">
                  <label>Department</label>
                  <select className="filter-select select-control" value={selectedDept} onChange={(e) => setSelectedDept(e.target.value)}>
                    {departments.map(d => <option key={d} value={d}>{d === 'All' ? 'All Departments' : d}</option>)}
                  </select>
                </div>
                <div className="filter-group">
                  <label>Year</label>
                  <select className="filter-select select-control" value={selectedYear} onChange={(e) => setSelectedYear(e.target.value)}>
                    {years.map(y => <option key={y} value={y}>{y === 'All' ? 'All Years' : y}</option>)}
                  </select>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div className="tags-scroll">
              <button className={`tag-pill ${!selectedTag ? 'active' : ''}`} onClick={() => setSelectedTag('')}>All Tags</button>
              {popularTags.map(tag => (
                <button key={tag} className={`tag-pill ${selectedTag === tag ? 'active' : ''}`} onClick={() => setSelectedTag(tag)}>
                  {tag}
                </button>
              ))}
            </div>

            {hasFilters && (
              <button onClick={clearFilters} className="clear-filters-btn">
                ✕ Clear active filters
              </button>
            )}
          </div>

          {/* Results count */}
          <div style={{ fontSize: '0.78rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
            {filteredProjects.length} result{filteredProjects.length !== 1 ? 's' : ''}
          </div>

          {/* Project Grid */}
          <div className="projects-grid">
            {filteredProjects.map(project => (
              <div key={project.id} className="project-card" onClick={() => setActiveProject(project)}>
                <div className="card-top-meta">
                  <div className="badge-group">
                    <span className="badge badge-level">{project.level}</span>
                    <span className="badge badge-type">{project.type}</span>
                  </div>
                  <span className="status-badge status-approved">Published</span>
                </div>
                <h3 className="project-card-title">{project.title}</h3>
                <p className="project-card-desc">{project.abstract}</p>
                <div style={{ marginTop: 'auto' }}>
                  <div className="project-authors">
                    {project.authors.join(', ')}
                  </div>
                  <div className="project-advisor">
                    Advisor: {project.advisors.join(', ')} · {project.department} · {project.year}
                  </div>
                  <div className="card-tags">
                    {project.tags.slice(0, 3).map(tag => (
                      <span key={tag} className="card-tag">{tag}</span>
                    ))}
                    {project.tags.length > 3 && <span className="card-tag">+{project.tags.length - 3}</span>}
                  </div>
                </div>
              </div>
            ))}

            {filteredProjects.length === 0 && (
              <div className="no-results" style={{ gridColumn: '1 / -1' }}>
                <div className="no-results-icon">🔍</div>
                <h3>No projects found</h3>
                <p>Try adjusting your search query or filters.</p>
                <button className="btn btn-secondary" style={{ marginTop: '1rem' }} onClick={clearFilters}>
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right: Analytics */}
        <div className="analytics-panel">
          
          {/* Donut Chart */}
          <div className="analytics-card">
            <h2>Research by Level</h2>
            <div className="chart-container">
              {levelData.total > 0 ? (
                <svg width="180" height="180" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="50" fill="transparent" stroke="var(--bg-3)" strokeWidth="10" />
                  {donutSlices.map(s => s.count > 0 && (
                    <circle
                      key={s.key} cx="60" cy="60" r="50"
                      fill="transparent" stroke={s.color} strokeWidth="10"
                      strokeDasharray={s.dashArray} strokeDashoffset={s.dashOffset}
                      strokeLinecap="round" transform="rotate(-90 60 60)"
                      style={{ transition: 'stroke-dashoffset 0.6s ease' }}
                    >
                      <title>{s.key}: {s.count} ({s.pct}%)</title>
                    </circle>
                  ))}
                  <circle cx="60" cy="60" r="36" fill="var(--bg-card, #141417)" />
                  <text x="60" y="57" textAnchor="middle" fill="var(--text-0)" fontSize="16" fontWeight="700" fontFamily="Space Grotesk">
                    {levelData.total}
                  </text>
                  <text x="60" y="70" textAnchor="middle" fill="var(--text-3)" fontSize="7" fontWeight="500" letterSpacing="0.8px" fontFamily="JetBrains Mono">
                    PROJECTS
                  </text>
                </svg>
              ) : (
                <div style={{ color: 'var(--text-4)' }}>No data</div>
              )}
            </div>
            <div className="chart-legend">
              <div className="legend-item">
                <span className="legend-color" style={{ backgroundColor: '#D4A853' }}></span>
                <span>BS ({levelData.BS.count})</span>
              </div>
              <div className="legend-item">
                <span className="legend-color" style={{ backgroundColor: '#4ADE80' }}></span>
                <span>MS ({levelData.MS.count})</span>
              </div>
              <div className="legend-item">
                <span className="legend-color" style={{ backgroundColor: '#A78BFA' }}></span>
                <span>PhD ({levelData.PhD.count})</span>
              </div>
            </div>
          </div>

          {/* Department Bars */}
          <div className="analytics-card">
            <h2>Departments</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              {deptData.map((dept, i) => {
                const max = Math.max(...deptData.map(d => d.count), 1);
                const pct = (dept.count / max) * 100;
                const color = barColors[i % barColors.length];
                return (
                  <div key={dept.name}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', fontWeight: 500, color: 'var(--text-2)', marginBottom: '3px' }}>
                      <span style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={dept.name}>{dept.name}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', color, fontWeight: 600 }}>{dept.count}</span>
                    </div>
                    <div style={{ width: '100%', height: '6px', backgroundColor: 'var(--bg-3)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ width: `${pct}%`, height: '100%', backgroundColor: color, borderRadius: '3px', transition: 'width 0.8s ease' }} />
                    </div>
                  </div>
                );
              })}
              {deptData.length === 0 && <div style={{ color: 'var(--text-4)', textAlign: 'center', padding: '1rem 0' }}>No data</div>}
            </div>
          </div>
        </div>
      </div>

      {/* ── Modal ─────────────────────────────── */}
      {activeProject && (
        <div className="modal-overlay" onClick={() => setActiveProject(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-header-title">
                <div style={{ display: 'flex', gap: '0.3rem' }}>
                  <span className="badge badge-level">{activeProject.level}</span>
                  <span className="badge badge-type">{activeProject.type}</span>
                </div>
                <h2>{activeProject.title}</h2>
              </div>
              <button className="modal-close-btn" onClick={() => setActiveProject(null)}>×</button>
            </div>

            <div className="modal-body">
              <div className="modal-meta-grid">
                <div className="meta-item">
                  <span className="meta-label">Authors</span>
                  <span className="meta-value">{activeProject.authors.join(', ')}</span>
                </div>
                <div className="meta-item">
                  <span className="meta-label">Department</span>
                  <span className="meta-value">{activeProject.department}</span>
                </div>
                <div className="meta-item">
                  <span className="meta-label">Advisor</span>
                  <span className="meta-value">{activeProject.advisors.join(', ')}</span>
                </div>
                <div className="meta-item">
                  <span className="meta-label">Year</span>
                  <span className="meta-value">{activeProject.year}</span>
                </div>
              </div>

              <div className="modal-abstract-section">
                <h3>Abstract</h3>
                <p className="modal-abstract-text">{activeProject.abstract}</p>
              </div>

              {/* Tags */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem', marginBottom: '1.5rem' }}>
                {activeProject.tags.map(tag => (
                  <span key={tag} className="card-tag" style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}>{tag}</span>
                ))}
              </div>

              {/* Links */}
              <div className="modal-links-section">
                <button
                  className="btn btn-primary"
                  style={{ flex: 1 }}
                  onClick={() => { setViewingDoc(activeProject); setActiveProject(null); }}
                >
                  View Document
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── In-App Document Viewer Modal ─── */}
      {viewingDoc && (
        <div className="modal-overlay" onClick={() => setViewingDoc(null)}>
          <div className="doc-viewer-modal" onClick={e => e.stopPropagation()}>
            <div className="doc-viewer-header">
              <div className="doc-viewer-title-bar">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                </svg>
                <span>{viewingDoc.title}</span>
              </div>
              <div className="doc-viewer-actions">
                {(viewingDoc.documentUrl.startsWith('blob:') || viewingDoc.documentUrl.startsWith('http')) && (
                  <a
                    href={viewingDoc.documentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-outline"
                    style={{ fontSize: '0.75rem', padding: '0.3rem 0.8rem' }}
                  >
                    Open in New Tab ↗
                  </a>
                )}
                <button className="modal-close-btn" onClick={() => setViewingDoc(null)}>×</button>
              </div>
            </div>

            <div className="doc-viewer-body">
              {(viewingDoc.documentUrl.startsWith('blob:') || viewingDoc.documentUrl.startsWith('http')) ? (
                <iframe
                  src={viewingDoc.documentUrl}
                  className="doc-viewer-iframe"
                  title={`Document: ${viewingDoc.title}`}
                />
              ) : (
                <div className="doc-viewer-thesis-preview">
                  <div className="thesis-page">
                    <div className="thesis-university-header">
                      <img src="/iiui-logo.png" alt="IIUI" className="thesis-logo" />
                      <h2>International Islamic University, Islamabad</h2>
                      <p>Faculty of Basic & Applied Sciences</p>
                      <p className="thesis-dept">Department of {viewingDoc.department}</p>
                    </div>

                    <div className="thesis-divider"></div>

                    <h1 className="thesis-title">{viewingDoc.title}</h1>

                    <div className="thesis-submitted">
                      <p className="thesis-label">Submitted by</p>
                      <p className="thesis-authors">{viewingDoc.authors.join(', ')}</p>
                      <p className="thesis-degree">{viewingDoc.level} {viewingDoc.type}</p>
                    </div>

                    <div className="thesis-body-text">
                      <p>
                        A {viewingDoc.type} submitted in partial fulfillment of the requirements for the 
                        Degree of <strong>{viewingDoc.type}</strong> in partial fulfillment 
                        of <strong>{viewingDoc.level}</strong> in <strong>{viewingDoc.department}</strong> at the 
                        Department of {viewingDoc.department}, International Islamic University, Islamabad.
                      </p>
                    </div>

                    <div className="thesis-advisor">
                      <p className="thesis-label">Research Advisor</p>
                      <p className="thesis-advisor-name">{viewingDoc.advisors.join(', ')}</p>
                    </div>

                    <div className="thesis-year">
                      <p>{viewingDoc.year}</p>
                    </div>

                    <div className="thesis-divider"></div>

                    <div className="thesis-abstract-section">
                      <h3>Abstract</h3>
                      <p>{viewingDoc.abstract}</p>
                    </div>

                    <div className="thesis-tags-section">
                      <h4>Keywords</h4>
                      <div className="thesis-tags">
                        {viewingDoc.tags.map(tag => (
                          <span key={tag} className="card-tag">{tag}</span>
                        ))}
                      </div>
                    </div>

                    <div className="thesis-watermark">IIUI RESEARCH REPOSITORY</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
