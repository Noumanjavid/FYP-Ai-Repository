const prompt = 'System: You are a helpful assistant.\nUser: Say hello and stop.';
fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`)
  .then(r => r.text())
  .then(console.log)
  .catch(console.error);
