// Mock database for the IIUI AI Research Showcase & Portal

// ─── All IIUI Departments ────────────────────────────────────────────
export const iiuiDepartments = [
  // Faculty of Computing & Information Technology
  "Computer Science",
  "Software Engineering",
  "Information Technology",
  "Artificial Intelligence",
  // Faculty of Engineering & Technology
  "Electrical Engineering",
  "Mechanical Engineering",
  "Civil Engineering",
  "Electronics Engineering",
  // Faculty of Basic & Applied Sciences
  "Mathematics & Statistics",
  "Physics",
  "Chemistry",
  "Bioinformatics & Biosciences",
  "Environmental Sciences",
  // Faculty of Management Sciences
  "Business Administration",
  "Project Management",
  "Business Analytics",
  "Accounting & Finance",
  "Management Sciences",
  // Faculty of Social Sciences
  "Economics",
  "Education",
  "Psychology",
  "Sociology",
  "Media & Communication",
  // Faculty of Languages & Literature
  "English",
  "Arabic",
  "Urdu",
  "Translation & Interpretation",
  // Faculty of Shariah & Law
  "Shariah (Islamic Law)",
  "Law",
  // Faculty of Usul al-Din (Islamic Studies)
  "Quran & Tafsir",
  "Hadith & Seerah",
  "Dawah & Islamic Culture",
  "Comparative Religion",
  // Faculty of International Relations
  "International Relations",
  "Political Science",
  // Faculty of Architecture & Design
  "Architecture",
  "Fine Arts & Design",
  // Health Sciences
  "Pharmacy",
  "Medical Sciences",
];

export const initialProjects = [
  // ── Computer Science ──────────────────────────────────────────
  {
    id: "proj-1",
    title: "UrduNastaliqOCR: High-Accuracy Optical Character Recognition for Nastaliq Script using CRNN and Attention Mechanisms",
    authors: ["Ahmad Ali", "Zainab Fatima"],
    advisors: ["Dr. Muhammad Sajid"],
    department: "Computer Science",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "OCR for the Urdu language remains a significant challenge due to the complex, cursive nature of the Nastaliq calligraphic script, which features overlapping characters, context-sensitive shapes, and non-horizontal writing lines. This thesis presents UrduNastaliqOCR, a deep learning-based framework that integrates Convolutional Recurrent Neural Networks (CRNN) with a visual attention mechanism for segment-free, end-to-end line recognition. Trained on a curated dataset of 100,000 Nastaliq text lines, our model achieves a character recognition accuracy of 96.4%, outperforming standard OCR architectures.",
    githubUrl: "https://github.com/iiui-repo/urdu-nastaliq-ocr",
    demoUrl: "https://youtube.com/watch?v=mock-urdu-ocr",
    documentUrl: "UrduNastaliqOCR_MS_Thesis.pdf",
    tags: ["Deep Learning", "Computer Vision", "Urdu OCR", "Recurrent Networks", "Attention Mechanism"],
    status: "Approved",
    grade: "",
    reviews: []
  },
  {
    id: "proj-3",
    title: "SmartFarms: Edge AI Node for Crop Disease Detection in Pakistani Agriculture using YOLOv8",
    authors: ["Hamza Yousaf", "Bilal Ahmed"],
    advisors: ["Dr. Muhammad Sajid"],
    department: "Computer Science",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "Early detection of crop diseases is vital to secure agricultural yields in Pakistan. This Final Year Project presents SmartFarms, an autonomous edge-computing device equipped with a high-definition camera and a micro-controller hosting a compressed YOLOv8 neural network. The device identifies disease symptoms with 91.2% mean Average Precision (mAP) and triggers alerts via LoRaWAN.",
    githubUrl: "https://github.com/iiui-repo/smartfarms-yolov8-edge",
    demoUrl: "",
    documentUrl: "SmartFarms_BS_Report.pdf",
    tags: ["Computer Vision", "YOLOv8", "Edge AI", "IoT", "Smart Agriculture"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Software Engineering ──────────────────────────────────────
  {
    id: "proj-2",
    title: "HadithSemantics: Semantic Search and Cross-Referencing of Hadith Narrations using Fine-Tuned Arabic BERT Models",
    authors: ["Usman Khan"],
    advisors: ["Dr. Asim Munir"],
    department: "Software Engineering",
    level: "PhD",
    type: "Research Paper",
    year: 2026,
    abstract: "Traditional search engines for Islamic scholarly literature rely on simple keyword matching, which fails to capture conceptual connections between Hadith narrations. HadithSemantics is an AI-powered semantic search engine driven by AraBERT, fine-tuned on classical Arabic religious texts. The system demonstrates a 40% improvement in thematic retrieval accuracy over BM25.",
    githubUrl: "https://github.com/iiui-repo/hadith-semantics-bert",
    demoUrl: "https://hadith-semantics.iiui.edu.pk",
    documentUrl: "HadithSemantics_PhD_Dissertation.pdf",
    tags: ["Arabic NLP", "Transformers", "BERT", "Semantic Search", "Knowledge Graphs"],
    status: "Approved",
    grade: "",
    reviews: []
  },
  {
    id: "proj-4",
    title: "UrduSpeechNet: End-to-End Urdu Automatic Speech Recognition for Assistive Educational Technologies",
    authors: ["Ayesha Bibi"],
    advisors: ["Dr. Asim Munir"],
    department: "Software Engineering",
    level: "MS",
    type: "Thesis",
    year: 2026,
    abstract: "Speech-interactive learning tools are effective for children and visually impaired learners, yet remain scarce for Urdu. UrduSpeechNet collects 200 hours of spoken Urdu and trains a customized Whisper encoder-decoder with adapter layers, achieving a WER of 12.8%.",
    githubUrl: "https://github.com/iiui-repo/urdu-speech-whisper",
    demoUrl: "",
    documentUrl: "UrduSpeechNet_MS_Thesis.pdf",
    tags: ["Speech Recognition", "Audio Processing", "Whisper Model", "Urdu NLP", "Assistive Tech"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Bioinformatics & Biosciences ──────────────────────────────
  {
    id: "proj-6",
    title: "CancerGNN: Graph Neural Networks for Predicting Drug-Target Interactions in Islamic Medicine Pharmacopoeia",
    authors: ["Maryam Nawaz"],
    advisors: ["Dr. Sadia Tariq"],
    department: "Bioinformatics & Biosciences",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "CancerGNN models the chemical constituents of medicinal herbs and human proteins as a heterogeneous graph. Using Graph Neural Networks with message passing, it predicts drug-target interactions focusing on cancer-related receptors (EGFR, VEGFR), identifying 12 high-probability compound-protein interactions validated in silico.",
    githubUrl: "https://github.com/iiui-repo/cancer-gnn-herbs",
    demoUrl: "",
    documentUrl: "CancerGNN_MS_Thesis.pdf",
    tags: ["Bioinformatics", "Graph Neural Networks", "Drug Discovery", "Deep Learning", "ChEMBL Integration"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Economics ──────────────────────────────────────────────────
  {
    id: "proj-7",
    title: "AI-Driven Macroeconomic Forecasting for Pakistan's GDP Using LSTM and External Debt Indicators",
    authors: ["Saad Rehman", "Hira Malik"],
    advisors: ["Dr. Tariq Masood"],
    department: "Economics",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "This thesis develops a deep-learning-based macroeconomic forecasting model using Long Short-Term Memory (LSTM) networks trained on 40 years of Pakistan Bureau of Statistics data. The model integrates external debt, remittances, trade deficit, and CPI as feature inputs and forecasts quarterly GDP growth with an RMSE improvement of 18% over ARIMA baselines. It serves as a decision-support tool for policymakers at the Ministry of Finance.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "LSTM_GDP_Forecast.pdf",
    tags: ["LSTM", "Macroeconomics", "Time-Series Forecasting", "Pakistan Economy", "Deep Learning"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Business Administration ───────────────────────────────────
  {
    id: "proj-8",
    title: "Predicting Consumer Purchase Behaviour on Pakistani E-Commerce Platforms Using Ensemble Machine Learning",
    authors: ["Fatima Zahra"],
    advisors: ["Dr. Amjad Hussain"],
    department: "Business Administration",
    level: "MS",
    type: "Research Paper",
    year: 2026,
    abstract: "This study applies Random Forest, XGBoost and stacked ensemble methods to a dataset of 500,000 transactions from a leading Pakistani e-commerce platform. Features include browsing sessions, cart abandonment rates, and demographic data. The ensemble model achieves 89.3% AUC for next-purchase prediction, enabling personalised marketing strategies.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "Ecommerce_ML_Paper.pdf",
    tags: ["Machine Learning", "E-Commerce", "Ensemble Methods", "Consumer Behavior", "Marketing Analytics"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Shariah (Islamic Law) ─────────────────────────────────────
  {
    id: "proj-9",
    title: "AutoFatwa: NLP-Based Classification and Retrieval of Islamic Legal Rulings Across Four Sunni Madhahib",
    authors: ["Abdullah Qureshi"],
    advisors: ["Dr. Hafiz Zubair"],
    department: "Shariah (Islamic Law)",
    level: "PhD",
    type: "Thesis",
    year: 2026,
    abstract: "AutoFatwa digitises and classifies over 120,000 fatwas from Dar-ul-Ifta collections across four Sunni schools of thought (Hanafi, Shafi'i, Maliki, Hanbali). Using fine-tuned multilingual BERT on classical Arabic and Urdu texts, the system categorises fatwas by Fiqh topic (worship, transactions, family law) with 91.4% accuracy and enables cross-madhab comparative retrieval for Islamic jurisprudence researchers.",
    githubUrl: "https://github.com/iiui-repo/auto-fatwa-nlp",
    demoUrl: "",
    documentUrl: "AutoFatwa_PhD_Thesis.pdf",
    tags: ["NLP", "Text Classification", "Arabic BERT", "Islamic Jurisprudence", "Information Retrieval"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Electrical Engineering ────────────────────────────────────
  {
    id: "proj-10",
    title: "Neural Fault Detection in Pakistan's National Power Grid Using Federated Learning on Smart Meter Data",
    authors: ["Hassan Raza", "Ali Kamran"],
    advisors: ["Dr. Farrukh Shahzad"],
    department: "Electrical Engineering",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "Pakistan's electricity distribution network suffers from significant transmission and distribution losses. This thesis deploys a Federated Learning framework across 500 simulated smart meters from WAPDA to train anomaly-detection CNNs without centralising sensitive consumer data. The system identifies transformer overloading, cable faults, and electricity theft with 94.1% detection accuracy while preserving user data privacy.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "FederatedGrid_MS_Thesis.pdf",
    tags: ["Federated Learning", "Anomaly Detection", "Smart Grid", "CNN", "Privacy-Preserving AI"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Education ─────────────────────────────────────────────────
  {
    id: "proj-11",
    title: "AI-Powered Adaptive Learning Platform for Remedial Mathematics in Pakistani Primary Schools",
    authors: ["Sana Gillani"],
    advisors: ["Dr. Nadia Iqbal"],
    department: "Education",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "This FYP builds an adaptive learning web app that uses a Bayesian Knowledge Tracing algorithm to model individual student mastery of Grade 3-5 mathematics concepts. The system generates personalised problem sets, adjusting difficulty in real-time based on error patterns. Piloted across 3 government schools in Rawalpindi, the platform improved student test scores by 22% over 8 weeks.",
    githubUrl: "https://github.com/iiui-repo/adaptive-math-pk",
    demoUrl: "",
    documentUrl: "AdaptiveMath_BS_Report.pdf",
    tags: ["Adaptive Learning", "EdTech", "Bayesian Knowledge Tracing", "Web App", "Education"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── International Relations ───────────────────────────────────
  {
    id: "proj-12",
    title: "Sentiment Analysis of Pakistan's Foreign Policy Coverage in Global Media Using Transformer Models",
    authors: ["Zain ul Abideen"],
    advisors: ["Dr. Khalid Mehmood"],
    department: "International Relations",
    level: "MS",
    type: "Research Paper",
    year: 2026,
    abstract: "This research applies RoBERTa-based sentiment and stance classification to 250,000 news articles from major global media outlets (BBC, CNN, Al Jazeera, Dawn) covering Pakistan's foreign policy from 2015–2025. The model detects sentiment polarity (positive/negative/neutral) and identifies framing biases across different media ecosystems with 87.2% F1-score.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "ForeignPolicy_Sentiment_Paper.pdf",
    tags: ["Sentiment Analysis", "Transformers", "RoBERTa", "Media Studies", "Political Analysis"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Psychology ────────────────────────────────────────────────
  {
    id: "proj-13",
    title: "Deep Learning for Early Detection of Depression from Urdu Social Media Posts",
    authors: ["Amna Tariq", "Rabia Shah"],
    advisors: ["Dr. Saima Mehboob"],
    department: "Psychology",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "Mental health detection in low-resource languages like Urdu is critically underserved. This thesis collects and annotates 50,000 Urdu-language posts from Twitter/X and Facebook with depression-related labels. A fine-tuned UrduBERT classifier identifies signs of clinical depression with 84.6% accuracy, providing early alerts for university counselling services.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "UrduDepression_MS_Thesis.pdf",
    tags: ["Mental Health AI", "Social Media Mining", "Urdu NLP", "Text Classification", "BERT"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Mathematics & Statistics ──────────────────────────────────
  {
    id: "proj-14",
    title: "Physics-Informed Neural Networks (PINNs) for Solving Partial Differential Equations in Fluid Dynamics",
    authors: ["Imran Saeed"],
    advisors: ["Dr. Naveed Ahmed"],
    department: "Mathematics & Statistics",
    level: "PhD",
    type: "Research Paper",
    year: 2026,
    abstract: "This dissertation introduces an enhanced PINN architecture incorporating Fourier feature embeddings and adaptive loss weighting to solve 2D Navier-Stokes equations with complex boundary conditions. Compared to standard PINNs, our method reduces solution error by 35% on benchmark turbulence cases and offers mesh-free computation advantages over finite element methods.",
    githubUrl: "https://github.com/iiui-repo/pinns-navier-stokes",
    demoUrl: "",
    documentUrl: "PINNs_PhD_Dissertation.pdf",
    tags: ["Physics-Informed Neural Networks", "PDE Solvers", "Fluid Dynamics", "Scientific Computing", "Deep Learning"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Media & Communication ─────────────────────────────────────
  {
    id: "proj-15",
    title: "AI-Generated Deepfake Detection in Pakistani Political Media Using Vision Transformers",
    authors: ["Noor Fatima"],
    advisors: ["Dr. Irfan Ullah"],
    department: "Media & Communication",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "This project builds a Chrome browser extension and mobile app that detects AI-generated deepfake videos of Pakistani politicians. Using Vision Transformer (ViT) models trained on a curated dataset of authentic and manipulated political speeches, the system achieves 93.7% accuracy on our test set and flags suspicious content in real-time for social media users.",
    githubUrl: "https://github.com/iiui-repo/deepfake-detector-pk",
    demoUrl: "",
    documentUrl: "Deepfake_BS_Report.pdf",
    tags: ["Deepfake Detection", "Vision Transformers", "Media Forensics", "Computer Vision", "Browser Extension"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Quran & Tafsir ────────────────────────────────────────────
  {
    id: "proj-16",
    title: "QuranicQA: A BERT-Based Question Answering System for Quranic Exegesis and Tafsir Cross-Referencing",
    authors: ["Muhammad Bilal"],
    advisors: ["Dr. Hafiz Umar"],
    department: "Quran & Tafsir",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "QuranicQA implements extractive and generative question-answering over a corpus of major Tafsir works (Ibn Kathir, Jalalayn, Maariful Quran) in Arabic and Urdu. The system uses AraBERT with retrieval-augmented generation (RAG) to answer scholarly queries like 'What are the conditions of valid Tawbah according to Ibn Kathir?' with cited verse and Tafsir references.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "QuranicQA_MS_Thesis.pdf",
    tags: ["Question Answering", "RAG", "AraBERT", "Islamic Studies", "NLP"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Law ───────────────────────────────────────────────────────
  {
    id: "proj-17",
    title: "LegalMind: AI-Assisted Case Law Summarisation and Prediction for Pakistan's Superior Courts",
    authors: ["Sara Iqbal", "Kamran Yousaf"],
    advisors: ["Dr. Zahid Anwar"],
    department: "Law",
    level: "MS",
    type: "Research Paper",
    year: 2026,
    abstract: "LegalMind applies transformer-based extractive summarisation to 80,000 judgments from the Supreme Court and High Courts of Pakistan. A secondary LSTM classifier predicts case outcomes (appeal allowed/dismissed) based on legal arguments and precedent citations with 78.4% accuracy, assisting lawyers in case preparation and legal research.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "LegalMind_MS_Paper.pdf",
    tags: ["Legal AI", "Text Summarization", "Case Prediction", "LSTM", "Pakistan Judiciary"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Pharmacy ──────────────────────────────────────────────────
  {
    id: "proj-18",
    title: "DrugInteractAI: Predicting Adverse Drug Reactions in Pakistani Patient Populations Using Graph Attention Networks",
    authors: ["Mehreen Aslam"],
    advisors: ["Dr. Faiza Naseem"],
    department: "Pharmacy",
    level: "MS",
    type: "Thesis",
    year: 2025,
    abstract: "Adverse Drug Reactions (ADRs) are a leading cause of hospital readmissions in Pakistan. DrugInteractAI models drug-drug and drug-gene interactions as a knowledge graph and applies Graph Attention Networks to predict ADR risk for common multi-drug regimens prescribed in Pakistani hospitals. Validated against FAERS data, it achieves 86.9% AUROC for ADR prediction.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "DrugInteractAI_MS_Thesis.pdf",
    tags: ["Graph Attention Networks", "Pharmacovigilance", "Drug Interactions", "Healthcare AI", "Knowledge Graphs"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Architecture ──────────────────────────────────────────────
  {
    id: "proj-19",
    title: "GenArch: Generative AI for Sustainable Islamic Architectural Design Using Diffusion Models",
    authors: ["Usama Tariq"],
    advisors: ["Dr. Aisha Siddiqui"],
    department: "Architecture",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "GenArch uses Stable Diffusion fine-tuned on a curated dataset of 10,000 images of Islamic geometric patterns, muqarnas, and sustainable building designs. Architects can provide text prompts like 'modern mosque with solar panels and traditional jali screens' and receive generated design concepts. The tool integrates with AutoCAD via a plugin for direct workflow adoption.",
    githubUrl: "https://github.com/iiui-repo/genarch-islamic-design",
    demoUrl: "",
    documentUrl: "GenArch_BS_Report.pdf",
    tags: ["Generative AI", "Stable Diffusion", "Islamic Architecture", "Sustainable Design", "CAD Integration"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── English ───────────────────────────────────────────────────
  {
    id: "proj-20",
    title: "AI-Powered Automated Essay Scoring for Pakistani English Language Learners Using GPT-Based Rubric Alignment",
    authors: ["Nimra Khalid"],
    advisors: ["Dr. Samina Raza"],
    department: "English",
    level: "MS",
    type: "Thesis",
    year: 2026,
    abstract: "This thesis develops an automated essay scoring (AES) system tailored for Pakistani English language learners at the intermediate level. Using GPT-4 with custom rubric-aligned prompting and a fine-tuned DeBERTa regression head, the system scores essays on grammar, coherence, and argumentation, achieving a Quadratic Weighted Kappa of 0.82 against expert human raters.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "AES_MS_Thesis.pdf",
    tags: ["Automated Essay Scoring", "GPT-4", "DeBERTa", "Language Assessment", "NLP"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Mechanical Engineering ────────────────────────────────────
  {
    id: "proj-21",
    title: "Predictive Maintenance of CNC Machines Using Vibration Sensor Data and 1D-CNN Classifiers",
    authors: ["Fahad Amin"],
    advisors: ["Dr. Kashif Riaz"],
    department: "Mechanical Engineering",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "This project deploys vibration sensors on three CNC lathe machines at a Taxila industrial workshop. A 1D Convolutional Neural Network processes accelerometer signals in real-time to classify bearing health states (normal, inner-race fault, outer-race fault) with 95.2% accuracy, enabling predictive maintenance scheduling and reducing unplanned downtime by 40%.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "PredictiveCNC_BS_Report.pdf",
    tags: ["Predictive Maintenance", "1D-CNN", "Vibration Analysis", "Manufacturing AI", "IoT Sensors"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Accounting & Finance ──────────────────────────────────────
  {
    id: "proj-22",
    title: "Islamic FinTech Fraud Detection: Identifying Suspicious Transactions in Shariah-Compliant Banking Using Autoencoders",
    authors: ["Omer Farooq"],
    advisors: ["Dr. Bilal Mehmood"],
    department: "Accounting & Finance",
    level: "MS",
    type: "Research Paper",
    year: 2026,
    abstract: "This study applies deep autoencoder-based anomaly detection to 2 million anonymised transactions from a Pakistani Islamic bank. The model identifies suspicious patterns including structuring, layering, and unusual Murabaha transactions with a precision of 91.3% and recall of 87.8%, outperforming rule-based AML systems currently deployed in the sector.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "IslamicFinTech_Fraud_Paper.pdf",
    tags: ["Fraud Detection", "Autoencoders", "Islamic Banking", "FinTech", "Anomaly Detection"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Hadith & Seerah ───────────────────────────────────────────
  {
    id: "proj-23",
    title: "IsnadGraph: Knowledge Graph Construction for Hadith Narrator Chain Analysis Using Named Entity Recognition",
    authors: ["Talha Mahmood"],
    advisors: ["Dr. Abdul Basit"],
    department: "Hadith & Seerah",
    level: "PhD",
    type: "Thesis",
    year: 2026,
    abstract: "IsnadGraph automatically extracts narrator names (rijal) from Arabic Hadith texts using a custom-trained Arabic NER model. It constructs a knowledge graph of 15,000+ narrators with relationships (teacher-student, contemporaries, geographical overlap). Scholars can visualise complete Isnad chains and identify weak links, supporting traditional Hadith authentication (Jarh wa Ta'dil) with modern computational tools.",
    githubUrl: "https://github.com/iiui-repo/isnad-graph-ner",
    demoUrl: "",
    documentUrl: "IsnadGraph_PhD_Thesis.pdf",
    tags: ["Named Entity Recognition", "Knowledge Graphs", "Arabic NLP", "Hadith Sciences", "Digital Humanities"],
    status: "Approved",
    grade: "",
    reviews: []
  },

  // ── Environmental Sciences ────────────────────────────────────
  {
    id: "proj-24",
    title: "Satellite Image Segmentation for Monitoring Deforestation in Northern Pakistan Using U-Net",
    authors: ["Aliya Khan"],
    advisors: ["Dr. Rashid Mahmood"],
    department: "Environmental Sciences",
    level: "BS",
    type: "Tangible Project",
    year: 2025,
    abstract: "This project uses U-Net semantic segmentation on Sentinel-2 satellite imagery to monitor deforestation in Khyber Pakhtunkhwa and Gilgit-Baltistan over 2018–2025. The model segments forest, barren land, water, and urban areas with 92.1% mean IoU. An interactive dashboard visualises year-over-year forest cover change for environmental agencies.",
    githubUrl: "",
    demoUrl: "",
    documentUrl: "Deforestation_UNet_BS_Report.pdf",
    tags: ["Satellite Imagery", "U-Net", "Semantic Segmentation", "Climate AI", "Remote Sensing"],
    status: "Approved",
    grade: "",
    reviews: []
  },
];
