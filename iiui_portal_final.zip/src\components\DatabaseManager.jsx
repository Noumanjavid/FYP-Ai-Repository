import React, { useState } from 'react';

export default function DatabaseManager({ 
  dbMode, 
  projects, 
  students, 
  onResetDatabase, 
  onImportData, 
  triggerNotification 
}) {
  const [importText, setImportText] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);

  // Template of a single project for the user to copy
  const sampleTemplate = [
    {
      "title": "Your Project Title Here",
      "authors": ["Author One", "Author Two"],
      "advisors": ["Supervisor Name"],
      "department": "Computer Science",
      "level": "BS",
      "type": "Thesis",
      "year": 2026,
      "abstract": "Enter a concise description/abstract of the research work done by the students here...",
      "documentUrl": "IIUI_Research_Document.pdf",
      "tags": ["AI", "Machine Learning"]
    }
  ];

  const handleDownloadTemplate = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(sampleTemplate, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "iiui_projects_template.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    triggerNotification("Template downloaded! Fill it out and upload below.", "success");
  };

  const handleExportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(projects, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "iiui_database_backup.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    triggerNotification("Database backup exported successfully!", "success");
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleImportSubmit = (e) => {
    e.preventDefault();
    
    // 1. Handle JSON Text Import
    if (importText.trim()) {
      try {
        const parsed = JSON.parse(importText);
        const projectsArray = Array.isArray(parsed) ? parsed : [parsed];
        
        // Validate basic fields
        const valid = projectsArray.every(p => p.title && p.authors && p.department);
        if (!valid) {
          alert("Invalid template format. Each project must have at least a 'title', 'authors' array, and 'department'!");
          return;
        }

        onImportData(projectsArray);
        setImportText('');
        triggerNotification(`Imported ${projectsArray.length} projects successfully!`, "success");
      } catch (err) {
        alert("Invalid JSON format! Please check the bracket alignment.");
      }
      return;
    }

    // 2. Handle JSON File Import
    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target.result);
          const projectsArray = Array.isArray(parsed) ? parsed : [parsed];
          
          // Validate
          const valid = projectsArray.every(p => p.title && p.authors && p.department);
          if (!valid) {
            alert("Invalid file format. Each project must contain at 'title', 'authors' list, and 'department'!");
            return;
          }

          onImportData(projectsArray);
          setSelectedFile(null);
          e.target.reset();
          triggerNotification(`Imported ${projectsArray.length} projects from file!`, "success");
        } catch (err) {
          alert("Error parsing file. Ensure it is a valid .json file.");
        }
      };
      reader.readAsText(selectedFile);
    }
  };

  return (
    <div className="main-content" style={{ animation: 'fadeUp var(--dur-normal) var(--ease-out)' }}>
      {/* Page Header */}
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 700, color: 'var(--text-0)', marginBottom: '0.5rem' }}>
          Database Settings & Controls
        </h1>
        <p style={{ color: 'var(--text-3)', fontSize: '0.9rem' }}>
          Manage your portal database structure, clear initial dummy records, and bulk upload your legit research.
        </p>
      </div>

      <div className="showcase-layout" style={{ gridTemplateColumns: '320px 1fr', gap: '2rem', display: 'grid' }}>
        
        {/* Left Side: DB Connection Status */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          
          {/* Status Box */}
          <div className="stat-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', borderLeft: '3.5px solid var(--border-color)' }}>
            <div>
              <h3 style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--text-0)', marginBottom: '0.25rem' }}>
                Database Mode
              </h3>
              <p style={{ color: 'var(--text-3)', fontSize: '0.75rem' }}>
                {dbMode === 'backend' ? 'Connected to local Node/Express database server' : 'Running serverless (Browser localStorage)'}
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{
                width: '10px', height: '10px', borderRadius: '50%',
                background: dbMode === 'backend' ? 'var(--emerald)' : 'var(--success)',
                boxShadow: dbMode === 'backend' ? '0 0 10px var(--emerald)' : 'none',
                display: 'inline-block'
              }}></span>
              <strong style={{ fontSize: '0.85rem', color: 'var(--text-0)' }}>
                {dbMode === 'backend' ? 'LIVE DATABASE' : 'BROWSER OFFLINE'}
              </strong>
            </div>
            
            <div style={{ fontSize: '0.78rem', color: 'var(--text-2)', background: 'var(--bg-2)', padding: '0.5rem 0.75rem', borderRadius: 'var(--r-sm)' }}>
              {dbMode === 'backend' ? (
                <span>Writes are saved permanently to <code>db.json</code> in your project root folder.</span>
              ) : (
                <span>Writes are saved to your browser session. Run <code>npm run start-db</code> to launch the server database!</span>
              )}
            </div>
          </div>

          {/* Database Actions */}
          <div className="stat-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', borderLeft: '3.5px solid var(--rose)' }}>
            <div>
              <h3 style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--text-0)', marginBottom: '0.25rem' }}>
                Wipe Dummy Data
              </h3>
              <p style={{ color: 'var(--text-3)', fontSize: '0.75rem' }}>
                Delete all preloaded sample publications and start with a completely empty repository.
              </p>
            </div>
            
            <button 
              className="btn" 
              onClick={() => {
                if (window.confirm("Are you sure you want to delete all current projects and start fresh? This cannot be undone!")) {
                  onResetDatabase();
                }
              }}
              style={{
                background: 'rgba(239, 68, 68, 0.08)',
                color: 'var(--rose)',
                border: '1px solid rgba(239, 68, 68, 0.15)',
                width: '100%',
                padding: '0.65rem'
              }}
            >
              🧹 Wipe All Projects
            </button>
          </div>

          {/* Backup Export */}
          <div className="stat-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div>
              <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: 'var(--text-0)', marginBottom: '0.25rem' }}>
                Backup & Export
              </h3>
              <p style={{ color: 'var(--text-3)', fontSize: '0.75rem' }}>
                Download your current repository project list as a JSON file.
              </p>
            </div>

            <button className="btn btn-secondary" onClick={handleExportData} style={{ width: '100%', padding: '0.65rem' }}>
              📥 Download Backup (.json)
            </button>
          </div>

        </div>

        {/* Right Side: Upload legit data */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          
          <div className="upload-card" style={{ padding: '2rem' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-0)', marginBottom: '0.5rem' }}>
              Upload Legit Research Data
            </h2>
            <p style={{ color: 'var(--text-3)', fontSize: '0.85rem', marginBottom: '1.5rem' }}>
              You can populate the portal with real research entries. Download the structured JSON template, fill it out with your project details, and upload the file or paste it below.
            </p>

            {/* Template Downloader Box */}
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center', 
              background: 'var(--gold-muted)', 
              border: '1px solid var(--border-accent)',
              padding: '1rem', 
              borderRadius: 'var(--r-md)',
              marginBottom: '2rem' 
            }}>
              <div>
                <strong style={{ fontSize: '0.85rem', color: 'var(--gold)', display: 'block' }}>IIUI Projects JSON Template</strong>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>A structured skeleton file with correct parameters.</span>
              </div>
              <button className="btn btn-primary" onClick={handleDownloadTemplate} style={{ padding: '0.5rem 1rem', fontSize: '0.8rem' }}>
                💾 Download Template
              </button>
            </div>

            {/* Import Form */}
            <form onSubmit={handleImportSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              
              {/* File Upload Zone */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: '0.85rem' }}>Upload JSON File</label>
                <div style={{
                  border: '2px dashed var(--border-default)',
                  borderRadius: 'var(--r-md)',
                  padding: '1.5rem',
                  textAlign: 'center',
                  cursor: 'pointer',
                  position: 'relative'
                }}>
                  <input 
                    type="file" 
                    accept=".json"
                    onChange={handleFileChange}
                    style={{
                      position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer'
                    }}
                  />
                  <div style={{ color: 'var(--text-3)', fontSize: '0.85rem' }}>
                    {selectedFile ? (
                      <strong style={{ color: 'var(--gold)' }}>📄 {selectedFile.name} ({selectedFile.size} bytes)</strong>
                    ) : (
                      'Drag & drop or click to select your filled "iiui_projects_template.json" file'
                    )}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <span style={{ flex: 1, height: '1px', background: 'var(--border-subtle)' }}></span>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-4)', textTransform: 'uppercase' }}>or paste json text</span>
                <span style={{ flex: 1, height: '1px', background: 'var(--border-subtle)' }}></span>
              </div>

              {/* Text Area Input */}
              <div className="form-group">
                <label style={{ fontWeight: 600, fontSize: '0.85rem' }}>JSON Raw Array</label>
                <textarea 
                  className="form-control"
                  rows="6"
                  placeholder='Paste your JSON array here. Example:
[
  {
    "title": "Smart Irrigation Anomaly Detection Using ANN",
    "authors": ["Saad Khan"],
    "advisors": ["Dr. Khalid"],
    "department": "Computer Science",
    "level": "BS",
    "type": "Thesis",
    "year": 2026,
    "abstract": "This project implements...",
    "tags": ["AI", "Smart Water"]
  }
]'
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  style={{
                    fontFamily: 'var(--font-mono)', fontSize: '0.78rem', background: 'var(--bg-0)', color: 'var(--text-1)'
                  }}
                />
              </div>

              <button 
                type="submit" 
                className="btn btn-primary" 
                disabled={!selectedFile && !importText.trim()}
                style={{ width: '100%', padding: '0.75rem' }}
              >
                🚀 Import & Save to Database
              </button>

            </form>
          </div>

        </div>

      </div>
    </div>
  );
}
