import React, { useState } from 'react';
import { iiuiDepartments } from '../data/mockData';

export default function StudentPortal({ 
  activeStudent,
  onRegister,
  onLogin,
  onLogout,
  onSubmitProject, 
  onDeleteProject,
  projects
}) {
  // Auth Form State
  const [isLogin, setIsLogin] = useState(true);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authDept, setAuthDept] = useState('Computer Science');

  // Project Upload Form State
  const [title, setTitle] = useState('');
  const [abstract, setAbstract] = useState('');
  const [authors, setAuthors] = useState('');
  const [projectDept, setProjectDept] = useState('Computer Science');
  const [level, setLevel] = useState('BS');
  const [type, setType] = useState('Thesis');
  const [advisor, setAdvisor] = useState('');
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [tagsInput, setTagsInput] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);

  // Authentication Handlers
  const handleAuthSubmit = (e) => {
    e.preventDefault();
    if (isLogin) {
      onLogin(authEmail, authPassword);
    } else {
      const success = onRegister(authName, authEmail, authPassword, authDept);
      if (success) {
        setIsLogin(true);
      }
    }
  };

  // Project form submit
  const handleProjectSubmit = (e) => {
    e.preventDefault();
    if (!title || !abstract || !authors) {
      alert("Please enter a title, abstract, and authors for your project.");
      return;
    }

    const authorsList = authors.split(',').map(a => a.trim()).filter(a => a.length > 0);
    const tagsList = tagsInput.split(',').map(t => t.trim()).filter(t => t.length > 0);

    const projectData = {
      title,
      authors: authorsList,
      advisors: [advisor],
      department: projectDept,
      level,
      type,
      year: parseInt(year) || new Date().getFullYear(),
      abstract,
      documentUrl: "IIUI_Research_Document.pdf", // will be replaced on backend upload
      tags: tagsList.length > 0 ? tagsList : ["AI", "Machine Learning"]
    };

    onSubmitProject(projectData, selectedFile);
    
    // Reset Form
    setTitle('');
    setAbstract('');
    setAuthors('');
    setProjectDept('Computer Science');
    setAdvisor('');
    setTagsInput('');
    setSelectedFile(null);
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) setSelectedFile(e.target.files[0]);
  };

  // Unauthenticated View (Login/Register Card)
  if (!activeStudent) {
    return (
      <div className="portal-layout centered">
        <div className="upload-card auth-card">
          <div className="auth-card-header">
            <div className="auth-card-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </div>
            <h2 className="auth-card-title">
              {isLogin ? 'Scholar Login' : 'Create Account'}
            </h2>
            <p className="auth-card-subtitle">
              {isLogin ? 'Sign in to manage your IIUI research uploads.' : 'Register with your @iiu.edu.pk email to upload work.'}
            </p>
          </div>

          <form onSubmit={handleAuthSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {!isLogin && (
              <>
                <div className="form-group">
                  <label>Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g. Ahmad Ali"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    required={!isLogin}
                  />
                </div>
                <div className="form-group">
                  <label>Department</label>
                  <select
                    className="form-control select-control"
                    value={authDept}
                    onChange={(e) => setAuthDept(e.target.value)}
                  >
                    {iiuiDepartments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
              </>
            )}

            <div className="form-group">
              <label>IIUI Email Address</label>
              <input
                type="email"
                className="form-control"
                placeholder="student@iiu.edu.pk"
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                required
              />
              {!isLogin && (
                <small className="form-helper-text">
                  * Must be a valid @iiu.edu.pk email address
                </small>
              )}
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                className="form-control"
                placeholder="••••••••"
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary btn-submit-auth">
              {isLogin ? 'Sign In' : 'Register Account'}
            </button>
          </form>

          <div className="auth-card-footer">
            <p>
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="btn-auth-switch"
              >
                {isLogin ? 'Register now' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Filter projects to only show ones uploaded by this student
  const studentProjects = projects.filter(p => p.uploaderEmail === activeStudent.email);

  // Authenticated View
  return (
    <div className="portal-layout">
      
      {/* Top Profile Summary Bar */}
      <div className="portal-top-bar">
        <div className="user-profile-info">
          <div className="user-avatar" style={{ background: 'var(--emerald-muted)', color: 'var(--emerald)' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </div>
          <div className="user-details">
            <h3>{activeStudent.name}</h3>
            <p>{activeStudent.department} · {activeStudent.email}</p>
          </div>
        </div>
        <button onClick={onLogout} className="btn btn-secondary">
          Sign Out
        </button>
      </div>

      <div className="showcase-layout">
        
        {/* Left Column: Upload Form */}
        <div className="upload-card">
          <h2>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--gold-light)' }}>
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
            Upload Research Work
          </h2>
          <form onSubmit={handleProjectSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            
            <div className="form-group">
              <label>Document Title</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Graph Neural Networks for Pathogen Detection"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label>Abstract</label>
              <textarea
                className="form-control"
                placeholder="Provide a comprehensive summary of your research methodology, implementation, and conclusion..."
                value={abstract}
                onChange={(e) => setAbstract(e.target.value)}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Author(s)</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Comma-separated names (e.g. Ahmad Ali, Zara Khan)"
                  value={authors}
                  onChange={(e) => setAuthors(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label>Research Supervisor</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Dr. Muhammad Sajid"
                  value={advisor}
                  onChange={(e) => setAdvisor(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label>Research Department</label>
              <select
                className="form-control select-control"
                value={projectDept}
                onChange={(e) => setProjectDept(e.target.value)}
              >
                {iiuiDepartments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Academic Level</label>
                <select
                  className="form-control select-control"
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                >
                  <option value="BS">Undergraduate (BS)</option>
                  <option value="MS">Postgraduate (MS)</option>
                  <option value="PhD">Doctoral (PhD)</option>
                </select>
              </div>

              <div className="form-group">
                <label>Publication Type</label>
                <select
                  className="form-control select-control"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                >
                  <option value="Thesis">Academic Thesis</option>
                  <option value="Research Paper">Research Paper / Article</option>
                  <option value="Tangible Project">Applied AI Project</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Research Tags / Keywords</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g. Deep Learning, NLP, Healthcare"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label>Publication Year</label>
                <input
                  type="number"
                  className="form-control"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  min="2010"
                  max="2035"
                />
              </div>
            </div>

            <div className="form-group" style={{ marginTop: '0.5rem' }}>
              <label>Manuscript / PDF Document</label>
              <div className={`file-upload-zone ${selectedFile ? 'has-file' : ''}`}>
                <input
                  type="file"
                  id="pdf-upload"
                  accept=".pdf"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                />
                <label htmlFor="pdf-upload" className="file-upload-label">
                  <div className="upload-zone-icon">
                    {selectedFile ? (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="12" y1="18" x2="12" y2="12"></line>
                        <polyline points="9 15 12 12 15 15"></polyline>
                      </svg>
                    ) : (
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                      </svg>
                    )}
                  </div>
                  <div className="upload-zone-text">
                    <span className="upload-main-text">
                      {selectedFile ? selectedFile.name : "Choose PDF manuscript"}
                    </span>
                    <span className="upload-sub-text">
                      {selectedFile ? "Click to change manuscript file" : "Drag and drop or click to browse (Max 50MB)"}
                    </span>
                  </div>
                </label>
              </div>
            </div>

            <div style={{ marginTop: '1rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border-subtle)' }}>
              <button type="submit" className="btn btn-primary" style={{ padding: '0.8rem 2.25rem' }}>
                Publish to Repository
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Manage Submissions dashboard */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          
          <div className="analytics-card" style={{ height: 'fit-content' }}>
            <h2 style={{ fontSize: '1rem' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '6px', color: 'var(--emerald)' }}>
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
              </svg>
              My Uploaded Projects
            </h2>
            <div className="student-projects-list">
              {studentProjects.map(proj => (
                <div key={proj.id} className="student-project-card">
                  <div className="student-project-card-header">
                    <div className="badge-group">
                      <span className="badge badge-level">{proj.level}</span>
                      <span className="badge badge-type">{proj.type}</span>
                    </div>
                    <div className="student-project-actions">
                      <a 
                        href={(proj.documentUrl.startsWith('blob:') || proj.documentUrl.startsWith('http')) ? proj.documentUrl : '#'}
                        target={(proj.documentUrl.startsWith('blob:') || proj.documentUrl.startsWith('http')) ? '_blank' : undefined}
                        rel="noopener noreferrer"
                        className="btn btn-outline btn-card-action"
                        onClick={(e) => {
                          if (!(proj.documentUrl.startsWith('blob:') || proj.documentUrl.startsWith('http'))) {
                            e.preventDefault();
                            alert('No PDF file was uploaded for this project. You can view it from the Explore Work page.');
                          }
                        }}
                      >
                        View
                      </a>
                      <button 
                        className="btn btn-danger btn-card-action" 
                        onClick={() => onDeleteProject(proj.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  
                  <h4 className="student-project-title">{proj.title}</h4>
                  
                  <div className="student-project-card-footer">
                    <span className="student-project-authors" title={proj.authors.join(', ')}>
                      Authors: {proj.authors.join(', ')}
                    </span>
                    <span className="student-project-year">{proj.year}</span>
                  </div>
                </div>
              ))}

              {studentProjects.length === 0 && (
                <div style={{ textAlign: 'center', padding: '3.5rem 0', color: 'var(--text-4)' }}>
                  <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: '1rem', opacity: 0.4, color: 'var(--text-3)' }}>
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                  </svg>
                  <p style={{ fontSize: '0.9rem', color: 'var(--text-3)', fontWeight: 500 }}>You haven't uploaded any projects yet.</p>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
