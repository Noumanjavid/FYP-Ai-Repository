fetch('https://text.pollinations.ai/What%20is%20the%20capital%20of%20France?')
  .then(res => res.text())
  .then(text => console.log('Response:', text))
  .catch(err => console.error('Error:', err));
